package com.dh.serviceregistryclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRegistryClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRegistryClientApplication.class, args);
	}

}
